#include <stdio.h>

int main() {
    int numero, i, fatorial;

    fatorial = 1;

    printf("Informe um numero: ");
    scanf("%d", &numero);

    for (i = numero; i >= 1; i--) {
        fatorial = fatorial * i;
    }

    printf("Fatorial = %d\n", fatorial);

    return 0;
}