#include <stdio.h>

int main() {
    int i;

    for (i = 1; i <= 5; i++) {
        printf("%d -> Quadrado: %d\n", i, i * i);
    }

    return 0;
}