#include <stdio.h>

int main() {
    int soma = 0, contador = 0, ultracontador = 0;

    printf("Digite um numero (digite 0 para sair): ");
    scanf("%d", &contador);

    while (contador != 0) {
        soma = soma + contador;
        ultracontador = ultracontador + 1;

        printf("Digite outro numero (digite 0 para sair): ");
        scanf("%d", &contador);
    }

    if (contador == 0) {
        printf("A soma foi: %d", soma);
        printf("\nQuantidade de numeros: %d", ultracontador);
    }

    return 0;
}