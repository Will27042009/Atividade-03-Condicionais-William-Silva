#include <stdio.h>

int main() {
    int multiplicacao, numero;

    printf("Digite um numero de 1 a 10: ");
    scanf("%d", &numero);

    for (int i = 1; i <= 10; i++) {
        multiplicacao = i * numero;
        printf("%d x %d = %d\n", i, numero, multiplicacao);
    }

    return 0;
}