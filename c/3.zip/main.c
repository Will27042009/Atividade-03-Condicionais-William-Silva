#include <stdio.h>

int main() {

      for (int i = 200; i >= 1; i--)  
{  
    printf("%d ", i);
}      
    return 0;
}