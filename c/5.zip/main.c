#include <stdio.h>

int main() {

    int num1;

    printf("Digite um numero: ");
    scanf("%d", &num1);

    for (int i = 0; i <= num1; i++) {
        printf("%d\n", i);
    }

    return 0;
}