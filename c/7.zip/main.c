#include <stdio.h>

int main() {
    int valor, pares;

    printf("Digite um numero de 0 ate 100: ");
    scanf("%d", &valor);

    for (pares = valor; pares <= 100; pares++) {
        if (pares % 2 == 0) {
            printf("%d\n", pares);
        }
    }

    return 0;
}