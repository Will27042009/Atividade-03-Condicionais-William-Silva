#include <stdio.h>

int main() {
    
     for (int i = 10; i <= 200; i++) {  
         printf("%d ", i);
    }
    return 0;
}